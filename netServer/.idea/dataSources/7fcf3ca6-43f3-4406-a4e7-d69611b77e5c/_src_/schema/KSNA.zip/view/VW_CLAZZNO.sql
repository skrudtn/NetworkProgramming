CREATE VIEW VW_CLAZZNO AS SELECT cl.clNo, cl.clName
FROM MEMBERS m, CD cd, CLAZZ cl
WHERE m.memNO = cd.memberNo and cd.cdNO = cl.cdNO
and m.id = 'ksna'  and cd.cdName = 'UML Manage Tool' and
  cd.reg_date = TO_DATE('2017-10-30 13:22:58','yyyy-mm-dd hh24:mi:ss')
/
