CREATE PROCEDURE InsertBook(
  myBookId    IN NUMBER,
  myBookName  IN VARCHAR2,
  myPublisher IN VARCHAR2,
  myPrice     IN NUMBER)
AS
  BEGIN
    INSERT INTO BOOK (BOOKID, BOOKNAME, PUBLISHER, PRICE)
    VALUES (myBookId, myBookName, myPublisher, myPrice);
  END;
/
